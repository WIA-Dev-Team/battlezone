//
/* file: CS325GraphicsDriver.cpp
/* author: djbouvier
/* date: 12 April 2011 
 */

#include <iostream>
#include <windows.h>
#include "cs325graphics.h"

int main(int argc, char* argv[])
{
	CS325Graphics window(argc, argv);

	float delta = 0.1;

	Point2D p1(-1.2, 1.2);
	Point2D p2(1.2, -1.2);
	Point2D p3(-1.2, -1.2);
	Point2D p4(1.2, 1.2);

	for(int i = 0; i < 10000; i++){

		cout << "draw lines" << endl;
		window.DrawLineOnScreen(p1, p2);
		window.DrawLineOnScreen(p4, p3);

		p1.setX(p1.getX() + delta);
		if(p1.getX() > CS325Graphics::X_MAX) delta *=-1;
		if(p1.getX() < CS325Graphics::X_MIN) delta *=-1;

		Sleep(100);

		window.DisplayNow();
		
	}
	
}




